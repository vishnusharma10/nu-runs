from django.contrib import admin
from .models import Donors
# Register your models here.
admin.site.register(Donors)
